Please find the task statement in the notebook 'PyTorch.ipynb'.

Please submit your implementation of 'utils.py' by sending the file to hartmut.bauermeister@uni-siegen.de. Use "DL 2019 6" as subject. Please provide the file (without parent folder!) in a zip-compressed archive with the name '<matriculation_number>_6.zip' or '<matriculation_number>_<matriculation_number>_6.zip' if you work in pairs. The submission deadline is Monday, 25.11.2019, 00:00. For further details on the submission formalities, visit https://www.vsa.informatik.uni-siegen.de/en/deep-learning-exercise-and-materials-0.
